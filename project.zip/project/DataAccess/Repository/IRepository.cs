﻿using BusinessObject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class IRepository<T> where T : class
    {
        protected FUFlowerBouquetManagementV4Context _context;
        public DbSet<T> _dbset;

        public IRepository()
        {
            _context = new FUFlowerBouquetManagementV4Context();
            _dbset = _context.Set<T>();
        }
        public List<T> GetAll()
        {
            return _dbset.ToList();
        }

        public T Get(int id)
        {
            return _dbset.Find(id);
        }

        public void Delete(int id)
        {
            var entity = _dbset.Find(id);
            if (entity != null)
            {
                _dbset.Remove(entity);
                _context.SaveChanges();
            }
        }

        public void Update(T entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            _dbset.Attach(entity);
            _context.SaveChanges();
        }

        public void Add(T entity)
        {
            _dbset.Add(entity);
            _context.SaveChanges();
        }
    }
}
