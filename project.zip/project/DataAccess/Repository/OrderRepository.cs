﻿


using BusinessObject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class OrderRepository : IRepository<Order>
    {

        public Order Add2(Order entity)
        {
            Add(entity);
            return entity;
        }

        public void Delete(int id)
        {
            var order = _context.Orders.SingleOrDefault(o => o.OrderId == id);
            if(order != null)
            {
                order.OrderStatus = "0";
                _context.SaveChanges();
            }
        }

        public void Add(Order entity)
        {
            var orders = GetAll();
            entity.OrderId = orders.Last().OrderId+1;
            _context.Orders.Add(entity);
            _context.SaveChanges();
        }
    }
}
