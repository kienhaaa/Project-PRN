﻿using BusinessObject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class ProductRepository : IRepository<FlowerBouquet>
    {
        public List<FlowerBouquet> GetAll1()
        {
            return _context.FlowerBouquets.Where(f => f.FlowerBouquetStatus==1).ToList();
        }

        public void Delete(int id)
        {
            var product = _context.FlowerBouquets.SingleOrDefault(p => p.FlowerBouquetId == id);
            if (product != null)
            {
                product.FlowerBouquetStatus = 0;
                _context.SaveChanges();
            }
        }

        public void Add(FlowerBouquet entity)
        {
            entity.FlowerBouquetId = GetAll().Count()+1;
            _context.FlowerBouquets.Add(entity);
            _context.SaveChanges();
        }

        public void Update(FlowerBouquet entity)
        {
            FlowerBouquet flowerBouquet = _context.FlowerBouquets.Find(entity.FlowerBouquetId);
            if(flowerBouquet != null)
            {
                flowerBouquet.FlowerBouquetName = entity.FlowerBouquetName;
                flowerBouquet.Description = entity.Description;
                flowerBouquet.UnitPrice = entity.UnitPrice;
                flowerBouquet.UnitsInStock = entity.UnitsInStock;
                flowerBouquet.CategoryId = entity.CategoryId;
                _context.SaveChanges();
            }
        }
    }
}
