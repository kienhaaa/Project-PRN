﻿using BusinessObject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class MemberRepository : IRepository<Customer>
    {
        public List<Customer> GetAll1()
        {
            return _context.Customers.ToList();
        }

       /* public void Delete(int id)
        {
            var entity = _context.Customers.Find(id);
            if (entity != null)
            {
                entity.CustomerStatus = 0;
                _context.SaveChanges();
            }
        }*/

        public void Add(Customer entity)
        {
            var customers = GetAll();
            entity.CustomerId = customers[customers.Count-1].CustomerId + 1;
            _context.Customers.Add(entity);
            _context.SaveChanges();
        }

        public void Update(Customer entity)
        {
            Customer customer = _context.Customers.Find(entity.CustomerId);
            if (customer != null)
            {
                customer.CustomerName = entity.CustomerName;
                customer.Email = entity.Email;
                customer.City = entity.City;
                customer.Country = entity.Country;
                customer.Password = entity.Password;
                customer.Birthday = entity.Birthday;
                _context.SaveChanges();
            }
        }
    }
}
