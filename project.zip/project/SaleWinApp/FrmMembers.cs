﻿using BusinessObject.Models;
using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SaleWinApp
{
    public partial class FrmMembers : Form
    {
        MemberRepository repos = new MemberRepository();
        public FrmMembers()
        {
            InitializeComponent();
        }

        private void FrmMembers_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = repos.GetAll1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to proceed?", "Add", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    repos.Add(new Customer
                    {
                        Email = textBox2.Text,
                        CustomerName = textBox3.Text,
                        City = textBox5.Text,
                        Country = textBox4.Text,
                        Password = textBox6.Text,
                        Birthday = dateTimePicker1.Value,

                    });

                    dataGridView1.DataSource = repos.GetAll1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            textBox1.Text = row.Cells[0].Value.ToString();

            textBox2.Text = row.Cells[1].Value.ToString();

            textBox3.Text = row.Cells[2].Value.ToString();

            textBox5.Text = row.Cells[3].Value.ToString();

            textBox4.Text = row.Cells[4].Value.ToString();

            textBox6.Text = row.Cells[5].Value.ToString();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to proceed?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int id = Convert.ToInt32(textBox1.Text);

                    repos.Delete(id);

                    dataGridView1.DataSource = repos.GetAll1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to proceed?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    repos.Update(new Customer
                    {
                        CustomerId = Convert.ToInt32(textBox1.Text),
                        Email = textBox2.Text,
                        CustomerName = textBox3.Text,
                        City = textBox5.Text,
                        Country = textBox4.Text,
                        Password = textBox6.Text,
                        Birthday = dateTimePicker1.Value,

                    });

                    dataGridView1.DataSource = repos.GetAll1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
    }
}
