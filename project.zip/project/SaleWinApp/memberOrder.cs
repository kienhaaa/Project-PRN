﻿using BusinessObject.Models;
using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class memberOrder : Form
    {
        OrderRepository repo = new OrderRepository();
        public Customer member;

        public memberOrder()
        {
            InitializeComponent();
        }

        private void memberOrder_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = repo.GetAll().Where(o => o.CustomerId == member.CustomerId).ToList();
            comboBox1.SelectedItem = "All";
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                switch (comboBox1.Text)
                {
                    case "All":
                        dataGridView1.DataSource = repo.GetAll().Where(o => o.CustomerId == member.CustomerId).ToList();
                        break;
                    case "ShippedDate":
                        dataGridView1.DataSource = repo.GetAll().Where(o => o.CustomerId == member.CustomerId).OrderByDescending(o => o.ShippedDate).ToList();
                        break;
                    case "OrderDate":
                        dataGridView1.DataSource = repo.GetAll().Where(o => o.CustomerId == member.CustomerId).OrderByDescending(o => o.OrderDate).ToList();
                        break;
                    case "Total":
                        dataGridView1.DataSource = repo.GetAll().Where(o => o.CustomerId == member.CustomerId).OrderByDescending(o => o.Total).ToList();
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
