﻿using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class frmOrder : Form
    {
        OrderRepository repo = new OrderRepository();

        public frmOrder()
        {
            InitializeComponent();
        }

        private void frmOrder_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = repo.GetAll();
            comboBox1.SelectedItem = "All";
        }

        private void comboBox1_DisplayMemberChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                switch (comboBox1.Text)
                {
                    case "All":
                        dataGridView1.DataSource = repo.GetAll();
                        break;
                    case "ShippedDate":
                        dataGridView1.DataSource = repo.GetAll().OrderByDescending(o => o.ShippedDate).ToList();
                        break;
                    case "OrderDate":
                        dataGridView1.DataSource = repo.GetAll().OrderByDescending(o => o.OrderDate).ToList();
                        break;
                    case "Total":
                        dataGridView1.DataSource = repo.GetAll().OrderByDescending(o => o.Total).ToList();
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
