﻿using BusinessObject.Models;
using BusinessObject.Utli;
using DataAccess.Repository;
using System.Data;

namespace SaleWinApp
{
    public partial class frmMain : Form
    {
        public Customer member;
        ProductRepository productRepository = new ProductRepository();
        MemberRepository memberRepository = new MemberRepository();
        OrderRepository orderRepository = new OrderRepository();
        OrderDetailRepository orderDetailRepository = new OrderDetailRepository();

        Dictionary<int, int> cart = new Dictionary<int, int>();

        public frmMain()
        {
            InitializeComponent();
        }

        private void productManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProducts frmProducts = new frmProducts();
            frmProducts.Show();
        }

        private void memberManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMembers frmMembers = new FrmMembers();
            frmMembers.Show();
        }

        private void orderHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmOrder frmOrder = new frmOrder();
            frmOrder.Show();
        }



        private void frmMain_Load(object sender, EventArgs e)
        {
            if (member.Email.Equals("Admin@fstore.com") && member.Password.Equals("admin@@"))
            {
                textBox1.Text = "your register base on admin authority";
                textBox1.ReadOnly = true;
                textBox2.ReadOnly = true;
                textBox3.ReadOnly = true;
                textBox4.ReadOnly = true;
                textBox5.ReadOnly = true;
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                orderHistoryToolStripMenuItem1.Visible = false;
            }
            else
            {
                textBox1.Text = member.Email;
                textBox2.Text = member.CustomerName;
                textBox3.Text = member.City;
                textBox4.Text = member.Country;
                textBox5.Text = member.Password;
                dataGridView1.DataSource = productRepository.GetAll();
                menuToolStripMenuItem.Visible = false;
            }


        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = member.Email;
            textBox2.Text = member.CustomerName;
            textBox3.Text = member.City;
            textBox4.Text = member.Country;
            textBox5.Text = member.Password;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                member.Email = textBox1.Text;
                member.CustomerName = textBox2.Text;
                member.City = textBox3.Text;
                member.Country = textBox4.Text;
                member.Password = textBox5.Text;

                memberRepository.Update(new Customer
                {
                    CustomerId = member.CustomerId,
                    Email = member.Email,
                    CustomerName = member.CustomerName,
                    City = member.City,
                    Country = member.Country,
                    Password = member.Password,
                    Birthday = member.Birthday,
                });
                dataGridView1.DataSource = productRepository.GetAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool process = true;
            try
            {
                if (cart.Count <= 0)
                {
                    MessageBox.Show("you havent done order");
                }
                else
                {
                    decimal total = 0;
                    foreach (KeyValuePair<int, int> pair in cart)
                    {
                        total += productRepository.Get(pair.Key).UnitPrice * pair.Value;
                        if (!util.checkUnitInStock(pair.Key, pair.Value))
                        {
                            process = false;
                            break;
                        }
                    }

                    if (process)
                    {
                        Order order = orderRepository.Add2(new Order
                        {
                            CustomerId = member.CustomerId,
                            OrderDate = DateTime.Now,
                            Total = total,
                            ShippedDate = DateTime.Now,
                            OrderStatus = "1"
                        });

                        foreach (KeyValuePair<int, int> pair in cart)
                        {
                            decimal price = productRepository.Get(pair.Key).UnitPrice * pair.Value;
                            orderDetailRepository.Add(new OrderDetail
                            {
                                OrderId = order.OrderId,
                                FlowerBouquetId = pair.Key,
                                UnitPrice = price,
                                Quantity = pair.Value,
                                Discount = 0
                            });
                        }
                        memberOrder memberOrder = new memberOrder();
                        memberOrder.member = this.member;
                        memberOrder.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("not enough unit in stock");
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void orderHistoryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            memberOrder memberOrder = new memberOrder();
            memberOrder.member = this.member;
            memberOrder.ShowDialog();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Check if the clicked column is a checkbox column
                if (dataGridView1.Columns[e.ColumnIndex] is DataGridViewCheckBoxColumn && e.RowIndex >= 0)
                {
                    int id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString());

                    // Perform your desired action
                    DataGridViewCheckBoxCell checkboxCell = (DataGridViewCheckBoxCell)dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
                    bool isChecked = (bool)checkboxCell.Selected;
                    if (isChecked)
                    {
                        int quan = 0;
                        if (dataGridView1.Rows[e.RowIndex].Cells[0].Value != null)
                        {
                            quan = Convert.ToInt32(((DataGridViewTextBoxCell)dataGridView1.Rows[e.RowIndex].Cells[0]).Value.ToString());
                        }

                        if (quan < 1)
                        {
                            MessageBox.Show("quantity too small");
                            ((DataGridViewCheckBoxCell)dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex]).Value = false;
                        }
                        else if (quan > 0)
                        {
                            bool iskey = cart.ContainsKey(id);
                            if (iskey)
                            {
                                cart[id] = quan;
                            }
                            else
                                cart.Add(id, quan);
                        }
                    }
                    else if (!isChecked)
                    {
                        cart.Remove(id);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("input quantity");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin frmLogins = new frmLogin();
            frmLogins.ShowDialog(); // Hiển thị form đăng nhập mới
        }
    }
}