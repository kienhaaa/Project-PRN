﻿using BusinessObject.Models;
using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class frmProducts : Form
    {
        ProductRepository repos = new ProductRepository();
        FUFlowerBouquetManagementV4Context context = new FUFlowerBouquetManagementV4Context();

        public frmProducts()
        {
            InitializeComponent();
        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = repos.GetAll1();
            comboBox1.DataSource = context.Categories.ToList();

            comboBox1.DisplayMember = "CategoryName";
            comboBox1.ValueMember = "CategoryId";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            textBox1.Text = row.Cells[0].Value.ToString();

            textBox2.Text = row.Cells[2].Value.ToString();

            textBox3.Text = row.Cells[4].Value.ToString();

            richTextBox1.Text = row.Cells[3].Value.ToString();

            numericUpDown1.Value = Convert.ToInt32(row.Cells[5].Value.ToString());

            comboBox1.SelectedValue = Convert.ToInt32(row.Cells[1].Value.ToString());

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to proceed?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int id = Convert.ToInt32(textBox1.Text);

                    repos.Delete(id);

                    dataGridView1.DataSource = repos.GetAll1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to proceed?", "Add", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    repos.Add(new FlowerBouquet
                    {
                        CategoryId = Convert.ToInt32(comboBox1.SelectedValue.ToString()),
                        FlowerBouquetName = textBox2.Text,
                        Description = richTextBox1.Text,
                        UnitPrice = Convert.ToDecimal(textBox3.Text),
                        UnitsInStock = Convert.ToInt32(numericUpDown1.Value),
                        FlowerBouquetStatus = 1
                    });

                    dataGridView1.DataSource = repos.GetAll1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to proceed?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    repos.Update(new FlowerBouquet
                    {
                        FlowerBouquetId = Convert.ToInt32(textBox1.Text),
                        CategoryId = Convert.ToInt32(comboBox1.SelectedValue.ToString()),
                        FlowerBouquetName = textBox2.Text,
                        Description = richTextBox1.Text,
                        UnitPrice = Convert.ToDecimal(textBox3.Text),
                        UnitsInStock = Convert.ToInt32(numericUpDown1.Value)
                    });

                    dataGridView1.DataSource = repos.GetAll1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                var data = context.FlowerBouquets.ToList();

                if (!string.IsNullOrEmpty(textBox1.Text.Trim()) && int.TryParse(textBox1.Text, out _))
                    data = data.Where(p => p.FlowerBouquetId == Convert.ToInt32(textBox1.Text)).ToList();

                if (!string.IsNullOrEmpty(textBox2.Text.Trim()))
                    data = data.Where(p => p.FlowerBouquetName.Contains(textBox2.Text)).ToList();

                if (!string.IsNullOrEmpty(textBox3.Text.Trim()))
                    data = data.Where(p => p.UnitPrice == Convert.ToDecimal(textBox3.Text)).ToList();

                if (numericUpDown1.Value != null && numericUpDown1.Value != 0 && numericUpDown1.Value > 0)
                    data = data.Where(p => p.UnitsInStock == Convert.ToInt32(numericUpDown1.Value)).ToList();

                dataGridView1.DataSource = data;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = repos.GetAll1();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            numericUpDown1.Value = 0;
            richTextBox1.Text = "";
            
        }
    }
}
