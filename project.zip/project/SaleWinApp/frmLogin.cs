﻿using DataAccess.Repository;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class frmLogin : Form
    {
        string adminEmail;
        string adminPassword;
        MemberRepository repo = new MemberRepository();
        public frmLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string email = textBox1.Text;
            string password = textBox2.Text;
            try
            {
                if (!string.IsNullOrEmpty(email.Trim()) && !string.IsNullOrEmpty(password.Trim()))
                {
                    if (email.Equals(adminEmail) && password.Equals(adminPassword))
                    {
                        this.Hide();

                        frmMain frmMain = new frmMain();
                        frmMain.member = new BusinessObject.Models.Customer
                        {
                            Email = adminEmail,
                            Password = adminPassword
                        };
                        frmMain.ShowDialog();
                    }
                    else if (repo.GetAll().SingleOrDefault(m => m.Email.Equals(email) && m.Password.Equals(password)) != null)
                    {
                        this.Hide();

                        frmMain frmMain = new frmMain();
                        frmMain.member = repo.GetAll().SingleOrDefault(m => m.Email.Equals(email) && m.Password.Equals(password));
                        frmMain.ShowDialog();

                    }
                    else
                    {
                        MessageBox.Show("wrong account");
                    }
                }
                else
                {
                    MessageBox.Show("empty text box");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            var configBuilder = new ConfigurationBuilder()
                          .SetBasePath(Directory.GetCurrentDirectory())
                          .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);

            var configuration = configBuilder.Build();

            adminEmail = configuration["Admin:Email"];
            adminPassword = configuration["Admin:Password"];


        }
    }
}
