﻿using BusinessObject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.Utli
{
    public class util
    {
        public static bool checkUnitInStock(int proidctId, int quantity)
        {
            using(var context = new FUFlowerBouquetManagementV4Context())
            {
                var product = context.FlowerBouquets.Find(proidctId);
                if(product.UnitsInStock > quantity)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
